'use strict';

var signup = require('./services/signup');
var category = require('./services/category');
var preferences = require('./services/preferences');


var controllers = { 
  signup: signup, 
  onboarding1: category, 
  onboarding2: preferences
};

module.exports = controllers;