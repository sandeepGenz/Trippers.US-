'use strict';

var controller = require('./controller');
var authValidation = require('./services/auth');

module.exports = function(app) {

    app.route('/api/v1/signup').post(controller.signup);

    app.route('/api/v1/onboarding/category').post(authValidation, controller.onboarding1 );

    app.route('/api/v1/onboarding/preferences').post(authValidation, controller.onboarding2);

    //app.route('/api/v1/browse').get(controller.onboarding1, authValidation); //TODO

    //app.route('/api/v1/destination').get(controller.onboarding1, authValidation); //TODO


};